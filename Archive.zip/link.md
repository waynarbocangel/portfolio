Part 1: https://waynarbocangel.com/methodtest
Part 3: https://waynarbocangel.com/login
        https://waynarbocangel.com/console
        https://waynarbocangel.com/